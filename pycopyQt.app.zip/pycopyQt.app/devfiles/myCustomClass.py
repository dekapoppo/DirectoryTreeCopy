#カスタムウィじぇえと（サブクラス？）がうまく読み込まれないので追加
#from droppablelineedit import DroppableLineEdit
class DroppableLineEdit(QLineEdit):
    def __init__(self, parent):
        super(DroppableLineEdit, self).__init__(parent)
        self.setDragEnabled(True)

    #Dropだけしか使わなくてもdragEventとdragMoveEventは必要！！！
    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls:
            event.accept()
        else:
            event.ignore()

    def dragMoveEvent(self, event):
        if event.mimeData().hasUrls:
            event.setDropAction(Qt.CopyAction)
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        if event.mimeData().hasUrls:
            event.setDropAction(Qt.CopyAction)
            event.accept()
            l = []
            for url in event.mimeData().urls(): #複数ファイル選択時も使える
                l.append(str(url.toLocalFile()))
                #self.emit(SIGNAL("dropped"), l)
            #なぜか末尾にスラッシュ残るときがあるので確認して修正
            if l[0][-1]=="/":
                self.setText(l[0][:-1]) #末尾削除
            else:
                self.setText(l[0])
        else:
            event.ignore()
